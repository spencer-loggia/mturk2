function convertStimSpaceForTablets(sname, fname, lumSD)
	
	
	tosave = [];  % suppresses erroneous errors
	
	if ~nargin
		nms = getSpaceShapeNames();
		
		sname = nms{1};  % rewards according to shapes & colors
		fname = nms{2};  % frequency of stimuli appearing
		lumSD = 5;  % decided upon
	elseif nargin == 1
		fname = sname{2};
		sname = sname{1};
		lumSD = 5;  % decided upon
    end
	
	% lspace
	% SD is expressed in GRID units - in reward and/or frequency space
	%  We desire +/- 10 Luminances, so 21 in total.
    %  This means we need 20 numbers (21 intervals)
    %  or 19 numbers on either side of center
    numLum = 21;
    numLim = (numLum-2)/2;
	lumX = -numLim:numLim;
	
	lumy = normcdf(lumX, 0, lumSD);
	
	
	
	load(sname, '-mat');
	nlvl = tosave(1);
	vlvl = tosave(1+(1:nlvl));
	vdat = tosave((2+nlvl):end);
	
	levels = vlvl;
	
	load(fname, '-mat');
	nlvl = tosave(1);
	plvl = tosave(1+(1:nlvl));
	pdat = tosave((2+nlvl):end);
		
	%  get the stimulus value space
	
	normalizedShapeSpace = MturkHelper.sumToOne(shapeSpace2D(vdat));
	rawRewardSpace = MturkHelper.convertToLevels(MturkHelper.maxToOne(normalizedShapeSpace), levels);
	rspace = rawRewardSpace(:);
	
	normalizedFreqSpace = MturkHelper.sumToOne(shapeSpace2D(pdat));
	fspace = normalizedFreqSpace(:);
	
    save([fname,'_freq'], 'fspace');
    save([sname,'_rewd'], 'rspace');
	
% 	outfilename = ['mturk2spaces_',num2str(now),'.txt'];
	outfilename = ['mturk2spaces_',sname,'.txt'];
	fid = fopen(outfilename, 'w');
	disp(outfilename);
	
	fprintf(fid, '//// space name = %s\r\n', sname);
	fprintf(fid, '//// freq name = %s\r\n', fname);
	fprintf(fid, '//// Lum SD = %d, %d values\r\n', [lumSD, length(lumX)]);
	
	%%% Frequency space
	fprintf(fid, '"frequencySpace":[');
	
	ns = length(fspace);
	for n = 1:(ns-1)
		val = fspace(n);
		fprintf(fid, '%1.9f, ', val);
		
	end;
	val = fspace(ns);
	fprintf(fid, '%1.9f];\r\n', val);
	
	
	%%% rewards for shapes
	fprintf(fid, '"rewardSpace":[');
	
	ns = length(rspace);
	for n = 1:(ns-1)
		val = rspace(n);
		fprintf(fid, '%d, ', val);
		
	end;
	val = rspace(ns);
	fprintf(fid, '%d];\r\n', val);
	
	
	%%% SD for luminance contrasts
	fprintf(fid, '"lumContrast":[');
	
	ns = length(lumy);
	for n = 1:(ns-1)
		val = lumy(n);
		fprintf(fid, '%1.9f, ', val);
		
	end;
	val = lumy(ns);
	fprintf(fid, '%1.9f];\r\n', val);
	
	
	
	fclose(fid);
	done;
	