function errorok


error('ok', 'Execution stopped by errorok');


